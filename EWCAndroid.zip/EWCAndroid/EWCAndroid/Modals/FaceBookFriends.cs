﻿using System;

namespace EWCAndroid
{
		public class FaceBookFriends
		{
			public Friends[] Data { get; set; }
		}

		public class Friends
		{
			public string Name { get; set; }
			public string Id { get; set; }
		}
}

